READ ME

customer_class.py: This python file holds the Customer Class
teller_class.py: This python file holds the Teller Class
project2.py: This python file is the file to be run and holds all function definitions.
Project-2-Write-Up.pdf: Write-up for Project 2

How to run:
    In order to run the project, simply go to the correct directory
    then input the following
        $ python3 project2.py