class Teller():
    def __init__(self, id):
        self.id = id
    def __str__(self):
        return f"Teller {self.id}"